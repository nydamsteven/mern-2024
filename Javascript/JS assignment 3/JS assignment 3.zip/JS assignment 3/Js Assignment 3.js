console.log('Hello World!')

let age;

age = prompt('Enter your Age')
console.log(age)
if(age <=16){
    console.log("Stay home, study, and get your driver's license")
}

else if(age >=18 && age < 21) {
    console.log("Have fun, but not TOO much fun. You're still a young adult")
}

if(age > 21) {
    console.log("Have fun. But be responsible. You are in control of your life")
}