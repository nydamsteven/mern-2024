console.log("Hello World")
console.log("Steven,", "Fav color: Blue")

var num1= 6 
var num2= 4

let num3= num1 + num2
console.log(num3)
// console.log(num1+num2)
// console.log(6+4)

let nameOne = "Steven"
let nameTwo = "Nydam"
console.log(nameOne +" " + nameTwo)

for (let i=1; i <=10; i++) {
    console.log(i)
}

for (let i=1; i <=5; i++) {
    console.log("Skillspire")
}



for (let i=0; i<=10; i++) {
    console.log(i*2)
}


for(let i=0; i <=20; i++) {
    if(i % 2 ==0)
    console.log(i)
}

for(let i=0; i <=20; i++) {
    if(i % 2 !=0)
    console.log(i)
}

for(let i=0; i <10; i++) {
    if(i % 2 == 0)
    console.log("FIZZ")
    if(i % 2 == 0)
    console.log("BUZZ")
}
