console.log('Hello!')


for (let i= 0; i <3; i++) {
    let img= document.createElement('img')
    img.src= "https://images.pushsquare.com/a919b03607c96/mass-effect-shepard-face.large.jpg"; 
    document.body.appendChild(img) 
}

