console.log('Wubba Lubba Dub Dub!!')

const aquaticAnimals = ["otter", "shark", "bluefin tuna"];
const rainforestAnimals = ["orang-utan", "elephant", "snake"];
const awesomeAnimals = [...aquaticAnimals, ...rainforestAnimals]

console.log(awesomeAnimals)